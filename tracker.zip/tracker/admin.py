from django.contrib import admin
from .models import Satellite
from .models import CustomUser
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

admin.site.register(CustomUser, UserAdmin)
admin.site.register(Satellite)






