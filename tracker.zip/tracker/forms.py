from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.hashers import make_password
from .models import CustomUser  # Update the import statement

class SignUpForm(UserCreationForm):
    username = forms.CharField(max_length=30, required=True, help_text='Required.')

    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'password1', 'password2']

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get('password1')

        if password and len(password) < 8:
            raise forms.ValidationError("Password must be at least 8 characters long")

        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.password = make_password(self.cleaned_data['password1'])
        user.username = self.cleaned_data['username']

        if commit:
            user.save()

        return user