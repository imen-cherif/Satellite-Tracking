from .models import Satellite, CustomUser
from rest_framework import serializers



class SatelliteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Satellite
        db_table = 'sat_db'
        fields = '__all__'

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'password', 'name', 'country']
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = CustomUser.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            name=validated_data['name'],
            country=validated_data['country']
        )
        return user

