from .views import SatelliteByCountryView, \
    SatellitesByOperatorView, CountriesByPurposeView, CountrySatelliteRankingView, DeleteSatellitesByCountryAPI, \
    ModifyPurposeByNoradNumberAPI, AddSatelliteAPI, SatellitesByLaunchSiteView, DeleteSatelliteByNoradNumberView, \
    UpdateSatelliteCountryByNoradNumberView, AddSatelliteSimpleAPI, telecommunication_satellites, first_page
from .views import iss_tracker
from django.urls import path
from rest_framework.routers import DefaultRouter
from .views import sat_apis
from .views import login
from .views import get_iss_position
from django.urls import path
from . import views
from .views import signup
from .views import login_view
from .views import SatelliteByNoradNumberView




router = DefaultRouter()

urlpatterns = [

    path('signup/', signup, name='signup'),
    path('login/', login_view, name='login'),
    path('first_page/', first_page, name='first_page'),
    path('sat_apis/', sat_apis, name='sat_apis'),
    path('telecommunication_satellites/', telecommunication_satellites, name='telecommunication_satellites'),
    path('iss_tracker/', iss_tracker, name='iss_tracker'),
    path('tracker/api/satellites/country/<str:country>/', SatelliteByCountryView.as_view(), name='satellites-by-country'),
    path('tracker/api/satellites/<int:norad_number>/', SatelliteByNoradNumberView.as_view(), name='satellite_by_norad_number'),
    path('tracker/api/satellites/by-operator/<str:operator_name>/', SatellitesByOperatorView.as_view(), name='satellites-by-operator'),
    path('tracker/api/countries/by-purpose/<str:purpose>/', CountriesByPurposeView.as_view(), name='countries-by-purpose'),
    path('tracker/api/countries/satellite-ranking/', CountrySatelliteRankingView.as_view(), name='country-satellite-ranking'),

    path('tracker/api/satellites/delete-by-country/<str:country>/', DeleteSatellitesByCountryAPI.as_view(), name='delete-satellites-by-country'),
    path('tracker/api/satellites/modify-purpose/<int:norad_number>/', ModifyPurposeByNoradNumberAPI.as_view(), name='modify-purpose-by-norad-number'),
    path('tracker/api/satellites/add/', AddSatelliteAPI.as_view(), name='add-satellite'),

    path('tracker/api/satellites/by-launch-site/<str:launch_site>/', SatellitesByLaunchSiteView.as_view(), name='satellites-by-launch-site'),
    path('tracker/api/satellites/delete-by-norad/<int:norad_number>/', DeleteSatelliteByNoradNumberView.as_view(), name='delete-satellite-by-norad'),
    path('tracker/api/satellites/update-country-by-norad/<int:norad_number>/', UpdateSatelliteCountryByNoradNumberView.as_view(), name='update-satellite-country-by-norad'),
    path('tracker/api/satellites/add_simple/', AddSatelliteSimpleAPI.as_view(), name='add-satellite-simple'),
    path('get_iss_position/', get_iss_position, name='get_iss_position'),
    path('iss_tracker/', iss_tracker, name='iss_tracker'),

]
