from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate
from django.contrib.auth import login
from django.contrib.auth import login as auth_login
from django.core.mail import send_mail
from django.db.models import Count
from django.shortcuts import get_object_or_404
from django.shortcuts import redirect
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from drf_yasg import openapi
from drf_yasg.utils import swagger_auto_schema
from rest_framework import generics
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .forms import SignUpForm
from .models import Satellite
from .serializers import SatelliteSerializer
import os
import subprocess
from django.http import JsonResponse
from django.conf import settings

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)

            # Send a welcome email to the user
            send_mail(
                'Welcome to Your Website',
                'Thank you for signing up!',
                settings.DEFAULT_FROM_EMAIL,
                [user.email],
                fail_silently=False,
            )

            return redirect('login')
        else:
            # Print form errors for debugging
            print(form.errors)
    else:
        form = SignUpForm()

    return render(request, 'signup.html', {'form': form})


def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = authenticate(request, email=email, password=password)

        if user is not None:
            login(request, user)
            # Redirect to the home page or any other desired page
            return redirect('sat_apis')
        else:
            # Authentication failed, show an error message
            messages.error(request, 'Invalid email or password. Please try again.')

    return render(request, 'login_page.html')


from django.shortcuts import render

def telecommunication_satellites(request):
    return render(request, 'index.html')

def first_page(request):
    return render(request, 'first.html')

def iss_tracker(request):
    return render(request, 'iss_tracker.html')

#First Page:

def sat_apis(request):
    return render(request, 'sat_apis.html')
@method_decorator(csrf_exempt, name='dispatch')
class SatelliteByCountryView(APIView):
    def get(self, request, country):
        satellites = Satellite.objects.filter(country_of_operator_owner=country)
        norad_numbers = satellites.values_list('norad_number', flat=True)
        return Response({"norad_numbers": list(norad_numbers)}, status=status.HTTP_200_OK)


class SatelliteByNoradNumberView(APIView):
    def get(self, request, norad_number):
        satellite = get_object_or_404(Satellite, norad_number=norad_number)

        # Selecting only the desired fields for the response
        response_data = {
            'official_name': satellite.official_name,
            'operator_owner': satellite.operator_owner,
            'purpose': satellite.purpose,
            'class_of_orbit': satellite.class_of_orbit,
        }
        return Response(response_data, status=status.HTTP_200_OK)


@method_decorator(csrf_exempt, name='dispatch')
class SatellitesByOperatorView(APIView):
    def get(self, request, operator_name):
        satellites = Satellite.objects.filter(operator_owner=operator_name)

        # Selecting only the desired fields for each satellite in the response
        response_data = []
        for satellite in satellites:
            satellite_info = {
                'official_name': satellite.official_name,
                'country_of_operator_owner': satellite.country_of_operator_owner,
                'use':satellite.users,
                'purpose': satellite.purpose,
                'launch_site': satellite.launch_site,
            }
            response_data.append(satellite_info)

        return Response(response_data, status=status.HTTP_200_OK)


@method_decorator(csrf_exempt, name='dispatch')
class CountriesByPurposeView(APIView):
    def get(self, request, purpose):
        satellites = Satellite.objects.filter(purpose=purpose)

        # Get a distinct list of countries for the specified purpose
        countries_info = []
        for country in satellites.values_list('country_of_operator_owner', flat=True).distinct():
            country_info = {
                country,
            }
            countries_info.append(country_info)

        return Response(countries_info, status=status.HTTP_200_OK)

class CountrySatelliteRankingView(APIView):
    def get(self, request):
        try:
            country_ranking = Satellite.objects.values('country_of_operator_owner').annotate(num_satellites=Count('norad_number')).order_by('-num_satellites')
            return Response(country_ranking, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@method_decorator(csrf_exempt, name='dispatch')
class DeleteSatellitesByCountryAPI(APIView):
    def delete(self, request, country):
        satellites = Satellite.objects.filter(country_of_operator_owner=country)
        satellites.delete()
        return Response({'message': f'Satellites of {country} deleted successfully'}, status=status.HTTP_204_NO_CONTENT)


# Additional API for modifying purpose by Norad Number
@method_decorator(csrf_exempt, name='dispatch')
class ModifyPurposeByNoradNumberAPI(APIView):
    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'new_purpose': openapi.Schema(type=openapi.TYPE_STRING),
            },
            required=['new_purpose'],
        ),
        responses={200: 'Successfully updated purpose', 400: 'Bad Request'},
    )
    def put(self, request, norad_number):
        satellite = get_object_or_404(Satellite, norad_number=norad_number)
        new_purpose = request.data.get('new_purpose')

        if new_purpose is not None:
            satellite.purpose = new_purpose
            satellite.save()
            return Response({'message': f'Purpose of satellite {norad_number} modified successfully'}, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'New purpose not provided in the request data'}, status=status.HTTP_400_BAD_REQUEST)



@method_decorator(csrf_exempt, name='dispatch')
class AddSatelliteAPI(generics.CreateAPIView):
    serializer_class = SatelliteSerializer
    queryset = Satellite.objects.all()

@method_decorator(csrf_exempt, name='dispatch')
class SatellitesByLaunchSiteView(APIView):
    def get(self, request, launch_site):
        satellites = Satellite.objects.filter(launch_site=launch_site)
        # Customize the response data as needed
        response_data = [...]  # Include relevant satellite details
        return Response(response_data, status=status.HTTP_200_OK)

@method_decorator(csrf_exempt, name='dispatch')
class DeleteSatelliteByNoradNumberView(APIView):
    def delete(self, request, norad_number):
        satellite = get_object_or_404(Satellite, norad_number=norad_number)
        satellite.delete()
        return Response({'message': f'Satellite {norad_number} deleted successfully'}, status=status.HTTP_204_NO_CONTENT)


@method_decorator(csrf_exempt, name='dispatch')
class UpdateSatelliteCountryByNoradNumberView(APIView):
    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'new_country': openapi.Schema(type=openapi.TYPE_STRING),
            },
            required=['new_country'],
        ),
        responses={200: 'Country updated successfully', 404: 'Satellite not found'},
    )
    def put(self, request, norad_number):
        satellite = get_object_or_404(Satellite, norad_number=norad_number)
        new_country = request.data.get('new_country')
        satellite.country_of_operator_owner = new_country
        satellite.save()
        return Response({'message': f'Country of satellite {norad_number} updated successfully'}, status=status.HTTP_200_OK)


@method_decorator(csrf_exempt, name='dispatch')
class AddSatelliteSimpleAPI(APIView):
    @swagger_auto_schema(
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            properties={
                'norad_number': openapi.Schema(type=openapi.TYPE_INTEGER),
                'official_name': openapi.Schema(type=openapi.TYPE_STRING),
                'operator_owner': openapi.Schema(type=openapi.TYPE_STRING),
                'purpose': openapi.Schema(type=openapi.TYPE_STRING),
                'class_of_orbit': openapi.Schema(type=openapi.TYPE_STRING),
            },
            required=['norad_number', 'official_name', 'operator_owner', 'purpose', 'class_of_orbit'],
        ),
        responses={201: 'Satellite added successfully', 400: 'Bad Request'},
    )
    def post(self, request):
        serializer = SatelliteSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Satellite added successfully'}, status=status.HTTP_201_CREATED)
        else:
            return Response({'error': 'Bad Request', 'details': serializer.errors}, status=status.HTTP_400_BAD_REQUEST)


def get_iss_position(request):
    # Build the absolute path to iss.py
    script_path = os.path.join(settings.BASE_DIR, 'tracker', 'iss.py')

    # Run the Python script
    try:
        subprocess.run(["python", script_path], check=True)
        result = {"success": True, "message": "ISS position retrieved successfully."}
    except subprocess.CalledProcessError as e:
        result = {"success": False, "message": f"Error: {e.returncode}"}

    return JsonResponse(result)