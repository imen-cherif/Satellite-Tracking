# models.py
from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    # add your custom fields if any
    pass


class Satellite(models.Model):
    norad_number = models.DecimalField(max_digits=10, decimal_places=0, primary_key=True)
    cospar_number = models.TextField()
    official_name = models.TextField()
    country_of_operator_owner = models.TextField()
    operator_owner = models.TextField()
    users = models.TextField()
    purpose = models.TextField()
    class_of_orbit = models.TextField()
    longitude_of_geo_degrees = models.FloatField(null=True, blank=True)
    perigee_km = models.FloatField(null=True, blank=True)
    apogee_km = models.FloatField(null=True, blank=True)
    inclination_degrees = models.FloatField(null=True, blank=True)
    period_minutes = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    launch_mass_kg = models.FloatField(null=True, blank=True)
    dry_mass_kg = models.FloatField(null=True, blank=True)
    expected_lifetime_years = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    launch_site = models.TextField()
    launch_vehicle = models.TextField()

    class Meta:
        db_table = 'sat_db'
        indexes = [
            models.Index(fields=['official_name']),
        ]

    def __str__(self):
        return str(self.norad_number)


